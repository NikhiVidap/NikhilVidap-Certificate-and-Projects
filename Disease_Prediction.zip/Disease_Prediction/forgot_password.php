<!Doctype html>
    <head>
        <title>Forgot Password</title>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
		<link rel="icon" href="diseas.png" type="image/png">
    </head>
    <body>
        <form method="post" role="form" action="forgot_password.php">
            <div>
                <label>Enter Phonenumber:</label>
                <input type="text" name="mob" placeholder="phone number" required>
            </div>
            <br>
            <div>
                <label>Enter new username:</label>
                <input type="text" name="un" placeholder="Enter username" required>
            </div>
            <br>
            <div>
                <label>Enter new password:</label>
                <input type="text" name="for" placeholder="Enter password" required>
            </div>
            <br>
            <input type="submit" value="Forgot Password" name="forgot" style="cursor: pointer;">
        </form>
    </body>
</html>
<?php 
require'registration_connection.php';

if(isset($_POST['forgot']))
{
 
    $phone=$_POST['mob'];
   
    $query="SELECT * FROM `user_info` WHERE Mobile=Mobile;";
    $data=mysqli_query($connect,$query);
    
 
    $datas=array();
    if(mysqli_num_rows($data)>0)
    {
       while($ans=mysqli_fetch_assoc($data))
       {
          
           $datas[]=$ans;
          
       }
    }
 
    
    
    foreach($datas as $sol)
    {  
       
       if($phone==$sol['Mobile'])
          {  
             $value=boolval(1);

             $uname=$_POST['un'];
                $forgot_password=$_POST['for'];
                $phone=$_POST['mob'];
             
                
                $query="UPDATE `user_info` SET `Username`='$uname',`Password`='$forgot_password'  WHERE Mobile=$phone";
                $data=mysqli_query($connect,$query);
                 
          }
       else         
          {
          
             $values=boolval(0);
             
          }
 
       
       
    }
    
    if($value==boolval(1))
    {
       echo"
    
       <script>
       alert('Succcessfully Username and Password changed');
       window.location= 'Loginpage.php';
       </script>
       ";
       
    }
    elseif($values==boolval(0))
    {
       echo"
       <script>
       
       alert('Wrong Mobile Number');
       </script>
       ";
 
    }
    
}
 
?>
