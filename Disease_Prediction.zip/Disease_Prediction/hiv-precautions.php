<!DOCTYPE html>
<head>
    <title>HIV Precautions</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
	<!--left-->
    <?php include('sidebar.php')?>
	



	<!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">HIV Precautions</h3>
    <hr>
    <br>
    <img src="hiv-precautions.jpg" width="500" height="500">
    <br>
    <br>

    <label><b>How is HIV transmitted?</b></label>
		<p>The person-to-person spread of HIV is called HIV transmission. People can get or transmit HIV only through specific activities, such as sex or injection drug use. HIV can be transmitted only in certain body fluids from a person who has HIV:
			1.Blood.<br>
			2.Semen.<br>
			3.Pre-seminal fluids.<br>
			4.Rectal fluids.<br>
			5.Vaginal fluids.<br>
		</p>

		<label><b>How can a person reduce the risk of getting HIV?</b></label>
		<p>Anyone can get HIV, but you can take steps to protect yourself from HIV.<br>
			1.Get tested for HIV. Talk to your partner about HIV testing and get tested before you have sex. Use the GetTested locator from the Centers for Disease Control and Prevention (CDC) to find an HIV testing location near you.<br>
			2.Choose less risky sexual behaviors. HIV is mainly spread by having anal or vaginal sex without a condom or without taking medicines to prevent or treat HIV.<br>
			3.Use condoms every time you have sex. Read this fact sheet from CDC on how to use condoms correctly.<br>
			4.Limit your number of sexual partners. The more partners you have, the more likely you are to have a partner with poorly controlled HIV or to have a partner with a sexually transmitted disease (STD). Both of these factors can increase the risk of HIV.<br>
			5.Get tested and treated for STDs. Insist that your partners get tested and treated, too. Having an STD can increase your risk of getting HIV or spreading it to others.<br>
			6.Talk to your health care provider about pre-exposure prophylaxis (PrEP). PrEP is an HIV prevention option for people who do not have HIV but who are at risk of getting HIV. PrEP involves taking a specific HIV medicine every day to reduce the risk of getting HIV through sex or injection drug use. For more information, read the HIVinfo fact sheet on Pre-Exposure Prophylaxis (PrEP).<br>
			7.Do not inject drugs. But if you do, use only sterile drug injection equipment and water, and never share your equipment with others.<br>
		</p>
		<div>
			<label>Save the file</label>
			<a href="HIV Precautions.pdf" download><img src="download.jpg" width="50" height="30" style="border: solid;"></a>
		</div>
</div>
</body>
</html>