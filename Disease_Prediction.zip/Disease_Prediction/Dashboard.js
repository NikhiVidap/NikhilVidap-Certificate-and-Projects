
function buttonclick()
{
    //alert("Button is clicked");
    
    $(".leftdiv").slideToggle();
    
}
function coronaclick(){
    $(".corona").slideToggle();


}
 function angelupcor(){
    
    document.getElementById("angeldowncor").style.visibility="visible";
    document.getElementById("angelupcor").style.visibility="hidden";
     


 }
function angeldowncor(){
   document.getElementById("angeldowncor").style.visibility="hidden";

    document.getElementById("angelupcor").style.visibility="visible";

}
function cancerclick(){
    $(".cancer").slideToggle();
}
function angelupcan(){
    
    document.getElementById("angeldowncan").style.visibility="visible";
    document.getElementById("angelupcan").style.visibility="hidden";
     


 }
function angeldowncan(){
   document.getElementById("angeldowncan").style.visibility="hidden";

    document.getElementById("angelupcan").style.visibility="visible";

}
function sugarclick(){
    $(".sugar").slideToggle();
}
function angelupsug(){
    
    document.getElementById("angeldownsug").style.visibility="visible";
    document.getElementById("angelupsug").style.visibility="hidden";
     


 }
function angeldownsug(){
   document.getElementById("angeldownsug").style.visibility="hidden";

    document.getElementById("angelupsug").style.visibility="visible";

}
function chickenclick(){
    $(".chicken").slideToggle();
}
function angelupchicken(){
    
    document.getElementById("angeldownchicken").style.visibility="visible";
    document.getElementById("angelupchicken").style.visibility="hidden";
     


 }
function angeldownchicken(){
   document.getElementById("angeldownchicken").style.visibility="hidden";

    document.getElementById("angelupchicken").style.visibility="visible";

}
function hivclick(){
    $(".hiv").slideToggle();
}
function angeluphiv(){
    
    document.getElementById("angeldownhiv").style.visibility="visible";
    document.getElementById("angeluphiv").style.visibility="hidden";
     


 }
function angeldownhiv(){
   document.getElementById("angeldownhiv").style.visibility="hidden";

    document.getElementById("angeluphiv").style.visibility="visible";

}
function dengueclick(){
    $(".dengue").slideToggle();
}
function angelupden(){
    
    document.getElementById("angeldownden").style.visibility="visible";
    document.getElementById("angelupden").style.visibility="hidden";
     


 }
function angeldownden(){
   document.getElementById("angeldownden").style.visibility="hidden";

    document.getElementById("angelupden").style.visibility="visible";

}
function maleriaclick(){
    $(".maleria").slideToggle();
}
function angelupmal(){
    
    document.getElementById("angeldownmal").style.visibility="visible";
    document.getElementById("angelupmal").style.visibility="hidden";
     


 }
function angeldownmal(){
   document.getElementById("angeldownmal").style.visibility="hidden";

    document.getElementById("angelupmal").style.visibility="visible";

}
function thyroidclick(){
    $(".thyroid").slideToggle();
}
function angelupthy(){
    
    document.getElementById("angeldownthy").style.visibility="visible";
    document.getElementById("angelupthy").style.visibility="hidden";
     


 }
function angeldownthy(){
   document.getElementById("angeldownthy").style.visibility="hidden";

    document.getElementById("angelupthy").style.visibility="visible";

}
function fluclick(){
    $(".flu").slideToggle();
}
function angelupflu(){
    
    document.getElementById("angeldownflu").style.visibility="visible";
    document.getElementById("angelupflu").style.visibility="hidden";
     


 }
function angeldownflu(){
   document.getElementById("angeldownflu").style.visibility="hidden";

    document.getElementById("angelupflu").style.visibility="visible";

}
function typhoidclick(){
    $(".typhoid").slideToggle();
}
function angeluptyp(){
    
    document.getElementById("angeldowntyp").style.visibility="visible";
    document.getElementById("angeluptyp").style.visibility="hidden";
    


 }
function angeldowntyp(){
    document.getElementById("angeldowntyp").style.visibility="hidden";

    document.getElementById("angeluptyp").style.visibility="visible";

}


