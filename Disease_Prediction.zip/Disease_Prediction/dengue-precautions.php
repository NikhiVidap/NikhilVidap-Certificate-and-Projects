<!DOCTYPE html>
<head>
    <title>Dengue Precautions</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
    <link rel="icon" href="diseas.png" type="image/png">
    <script src="Js/jquery.js"></script>
    <script src="Dashboard.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->

    <?php include('sidebar.php')?>
    

    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Dengue Precautions</h3>
    <hr>
    <br>
    <img src="dengue-precautions.jpg" width="500" height="500">
    <br>
    <br>
    <p>
                The mosquitoes that spread dengue are active during the day. <br>
        Lower the risk of getting dengue by protecting yourself from mosquito bites by using: <br>
            1.clothes that cover as much of your body as possible.<br>
            2.mosquito nets if sleeping during the day, ideally nets sprayed with insect repellent.<br>
            3.window screens.<br>
            4.mosquito repellents (containing DEET, Picaridin or IR3535).<br> 
            5.coils and vaporizers.<br>
            </p>
            <p>
                If you get dengue, it’s important to:<br>
                1.rest<br>
                2.drink plenty of liquids.<br>
                3.use acetaminophen (paracetamol) for pain.<br>
                4.avoid non-steroidal anti-inflammatory drugs, like ibuprofen and aspirin.<br>
                5.watch for severe symptoms and contact your doctor as soon as possible if you notice any.<br>
            </p>

            <div>
                <label>Save the file</label>
                <a href="Dengue Fever Precautions.pdf" download><img src="download.jpg" width="50" height="30" style="border: solid;"></a>
            </div>
</div>
</body>
</html>