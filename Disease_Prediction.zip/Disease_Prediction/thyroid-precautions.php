<!DOCTYPE html>
<head>
    <title>Thyroid Precautions</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    </head>
<body>
    <!--left-->
    <?php include('sidebar.php')?>

    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Thyroid Precautions</h3>
    <hr>
    <br>
    <img src="thyroid exercise.jpg" widht="500" height="500">
    <br>
    <img src="thyroid-precautions.jpg" width="750" height="500">
    <br>
    <br>

    <p>
                <b>The Do</b><br>
        1. Check thyroid regularly:<br>
        It is important to check thyroid levels regularly- whether you do it at home or via a lab test, it is up to you. At times, a doctor may completely depend upon the blood test for diagnosis and overlook thyroid dysfunction. This may leave many people undiagnosed. Therefore, it is important to have a frank discussion with your doctor and seek clarity.
        If you want to test your thyroid levels at home, you will need a glass basal thermometer. You can check your temperature daily for 10 minutes. Take precautions as per your temperature.<br>
        2. Drink a lot of water:<br>
        Thyroid patients must always drink distilled water. This is because chlorine, fluoride and bromine levels are very low and it is iodine-free which helps the thyroid to function properly. Distilled water also ensures cleaning the liver and kidneys of toxins.<br>
    </p>
        <p>
                <b>The Don’ts</b><br>
            1. Avoid smoking or drinking alcohol:<br>
            Thyroid patients, if they smoke or drink alcohol, should put a stop to these immediately. This is because alcohol is a depressant and it suppresses the thyroid gland functions. Tobacco or smoking is equally harmful as it blocks the iodide ration and synthesis of hormones.
            Read More: 7 Health Hazards of Smoking.<br>
            2. Say no to macronutrients:<br>
            Fats, protein and carbohydrates are the big macronutrients. They play a significant role in thyroid regulation in the body. However, following a low-carb diet can adversely affect the thyroid. Even diets that are non-fat or trans-fat pose problems for thyroid patients.<br>
            3. Stay away from sugar and caffeine:<br>
            Caffeine tends to stress the body and so does sugar. Consuming caffeine in smaller quantities is good as it helps to manage inflammation, as it helps to open up the blood vessels. However, consuming more than the recommended amount of caffeine can alter the TSH levels produced by the pituitary glands.
        </p>
        <div>
            <label>Save the file</label>
            <a href="Thyroid Precauions.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
        </div>
</div>

</body>
</html>