<html>
    <head>
        <title>Cancer symptoms</title>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    </head>
    <body>
        <!--left-->
        <?php include('sidebar.php')?>
       
        <!--center-->
        <!--Cancer-->
	<div id="diseas" style="width:100%;max-width:750px;">
        <div>
            <h1 align="center">Cancer</h1>
        </div>
        <hr>
        <div>
            <label>Symptoms of Cancer</label>
            <ol>  
            <li> Cancer can cause many symptoms, but these symptoms are most often caused by illness, injury, benign tumors, or other problems. ...</li>
              <li>  Bladder changes.</li>
              <li>  Bleeding or bruising, for no known reason.</li>
               <li>Bowel changes.</li> 
                <li>Cough or hoarseness that does not go away.</li>
               <li> Eating problems.</li>
              <li>  Fatigue that is severe and lasts.</li>
            </ol>
        </div>
		 <label>Save the file</label>

		<a href="Cancer.pdf" download>
                <img src="download.jpg" width="50" height="30" class="ima" style="border:solid">
              </a>
			  <!--Blood Cancer-->
			  <div>
            <h1 align="center">Blood cancer</h1>
        </div>
        <hr>
        <img src="Blood-Cancer-Symptoms.jpg" width="500"height="500">
        <div>
            <label>Common blood cancer symptoms explained</label>
            <ol>
           <li> Tiredness, breathlessness, paleness.</li>
            <li>Unexplained rash, bruising or bleeding.</li>
           <li> Infections or unexplained fever.</li>
            <li>Lumps and swellings.</li>
           <li> Bone pain.</li>
           <li> Drenching night sweats.</li>
           <li> Itchy skin.</li>
           <li> Unexplained weight loss.</li>
        </ol>
        </div>
		<label>Save the file</label>
            <a href="blood cancer.pdf" download>
                <img src="download.jpg" width="50" height="30" class="ima" style="border:solid">
              </a>
			  <!--Skin Cancer-->
	    <div>
         <h1 align="center">Skin cancer</h1>
        </div>
        <hr>
         <!--skin caner video-->
        <div> <label>Skin Cancer, Causes, Signs and Symptoms, Diagnosis and Treatment:</label></div>
        

        <img src="Symptoms-of-skin-cancer.jpg" width="500" height="500">
        <br>
        <br>
        <div>
        <label>Most common symptoms:</label>
        <ol>
           <li> A large brownish spot with darker speckles</li>
            <li>A mole that changes in color, size or feel or that bleeds</li>
           <li> A small lesion with an irregular border and portions that appear red, pink, white, blue or blue-black</li>
            <li>A painful lesion that itches or burns</li>
            <li>Dark lesions on your palms, soles, fingertips or toes, or on mucous membranes lining your mouth, nose, vagina or anus</li>
        </ol>
         </div>
	    <label>Save the file</label>
        <a href="Skin cancer.pdf" download>
            <img src="download.jpg" width="50" height="30" class="ima" style="border:solid">
          </a>
    </div>
    </body>
</html>