<!DOCTYPE html>
<head>
    <title>Flu Symptoms</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->
    <?php include('sidebar.php')?>
    

    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Flu Symptoms</h3>
    <hr>
    <br>
    <img src="flu symptoms.jpg" width="500" height="500">
    <br>
    <br>
    <p>
        FLU Symptoms:<br> 
    	1.Sudden onset of high fever.<br>
    	2.Headache, muscle aches and joint pain.<br>
    	3.Cough (usually dry).<br>
    	4.Chills.<br>
    	5.Sore throat.<br>
    	6.Nasal congestion and runny nose.<br>
    	7.Fatigue.<br>
    	8.Stomach symptoms such as nausea, vomiting or diarrhea may occur but are more common in children than adults.<br>
    </p>
    <div>
        <label>Save the file</label>
        <a href="Flu Symptoms.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
    </div>

</div>
</body>
</html>