<html>
    <head>
        <title>Sugar precautions</title>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
		    </head>
    <body>
        <!--left-->
    <?php include('sidebar.php')?>
        
	
        <!--center-->
    <div id="diseas" style="width:100%;max-width:750px;">
        <h2 align="center">Sugar precautions</h2>
        <hr>
        <label>1.Make a commitment to managing your diabetes</label>
        <p>Monitor your blood sugar, and follow your health care provider's instructions for managing your blood sugar level. Take your medications as directed by your health care provider. Ask your diabetes treatment team for help when you need it.</p>
        <label>2.Don't smoke</label>
        <p>Avoid smoking or quit smoking if you smoke. Smoking increases your risk of type 2 diabetes and the risk of various diabetes complications, including:</p>
        <ol>
            <li>Reduced blood flow in the legs and feet, which can lead to infections, nonhealing ulcers and possible amputation</li>
            <li>Worse blood sugar control</li>
            <li>Heart disease</li>
            <li>Stroke</li>
            <li>Eye disease, which can lead to blindness</li>
            <li>Nerve damage</li>
            <li>Kidney disease</li>
            <li>Premature death</li>
        </ol>

        <label>3. Keep your vaccines up to date</label>
        <p>Diabetes increases your risk of getting certain illnesses. Routine vaccines can help prevent them. Ask your health care provider about:</p>
        <ol>
            <li><b>Flu vaccine: </b> yearly flu vaccine can help you stay healthy during flu season as well as prevent serious complications from the flu.</li>
            <li><b>Pneumonia vaccine:</b> Sometimes the pneumonia vaccine requires only one shot. If you have diabetes complications or you're age 65 or older, you may need a booster shot.</li>
            <li><b>Hepatitis B vaccine:</b> The hepatitis B vaccine is recommended for adults with diabetes who haven't previously received the vaccine and are younger than 60. If you're age 60 or older and have never received the hepatitis B vaccine, talk to your health care provider about whether it's right for you.</li>
            <li><b>Other vaccines: </b>Stay up to date with your tetanus shot (usually given every 10 years). Your doctor may recommend other vaccines as well.</li>
        </ol>
        <label>4 . Take care of your teeth</label>
            <p>Diabetes may leave you prone to gum infections. Brush your teeth at least twice a day with a fluoride toothpaste, floss your teeth once a day and schedule dental exams at least twice a year. Call your dentist if your gums bleed or look red or swollen.</p>
        <label>5. Pay attention to your feet</label>
            <p>High blood sugar can reduce blood flow and damage the nerves in your feet. Left untreated, cuts and blisters can lead to serious infections. Diabetes can lead to pain, tingling or loss of sensation in your feet.</p>
        <div>
            <label>Save the file</label>
            <a href="Sugar precautions.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
        </div>
    </div>    
    </body>
</html>