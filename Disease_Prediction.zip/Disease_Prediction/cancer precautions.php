<html>
    <head>
        <title>Cancer Precautions</title>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    </head>
    <body>
        <!--leftdiv-->
        <?php include('sidebar.php')?>

<!--center-->
    <div id="diseas" style="width:100%;max-width:750px;">      
        <div> <h2>Skin Cancer, Causes, Signs and Symptoms, Diagnosis and Treatment:</h2></div>
        
        <br>
        <br>
        <label>Cancer Precautions</label>
                By following few healthy lifestyle habits given below one can reduce the chances of getting affected with any type of cancer.
        <ol>
             	<li>Regular Exercise:
            Regular exercise is essential to keep the body healthy. If you exercise daily for 30 minutes there are less chances of getting affected to the blood cancer, but still there is no evidence which supports it.</li>
        	<li>Eat Healthy:
            Healthy food consumption helps you to fight against diseases. Increasing consumption of fresh fruits and vegetables that contain fibers and a lot of nutrients reduces the risk of blood cancer to some extent.</li>
            	<li>Don't Ignore the Symptoms:
            Be watchful of your body and the signals it gives to you, especially when you are being exposed to one . Always consult your doctor when any kind of signs related to the cancer is seen.</li>
        </ol>
        Skin cancer precautions:
        <ol>
            Skin cancer is one of the most common kinds of cancer and one of the most preventable. Try these tips:
            	<li>Avoid midday sun. Stay out of the sun between 10 a.m. and 4 p.m. when the sun's rays are strongest.</li>
            	<li>Stay in the shade. When outdoors, stay in the shade as much as possible. Sunglasses and a broad-brimmed hat help too.</li>
            	<li>Cover your skin. Wear clothing that covers as much skin as possible. Wear a head cover and sunglasses. Wear bright or dark colours.
                      They reflect more of the sun's harmful rays than do pastels or bleached cotton.</li>
            	<li>Don't skimp on sunscreen. Use a broad-spectrum sunscreen with an SPF of at least 30, even on cloudy days. Apply a lot of sunscreen. Apply again every two hours, or more often after swimming or sweating.</li>
        </ol>
        <label>Save the file</label>
        <a href="cancer precaution.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid">   </a>

    </div>
 
    </body>
</html>