<!DOCTYPE html>
<head>
    <title>Malaria Precautions</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->
    <?php include('sidebar.php')?>
    
    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3>Malaria Precautions</h3>
    <hr>
    <br>
    <img src="malaria precautions.jpg" width="500" height="500">
    <br>
    <br>
    <p>
            Malaria can be prevented by avoiding mosquito bites or by taking medicines. Talk to a doctor about taking medicines such as chemoprophylaxis before travelling to areas where malaria is common.<br>
        Lower the risk of getting malaria by avoiding mosquito bites:  <br>
        	1.Use mosquito nets when sleeping in places where malaria is present.<br>
        	2.Use mosquito repellents (containing DEET, IR3535 or Icaridin) after dusk.<br>
        	3.Use coils and vaporizers.<br>
        	4.Wear protective clothing.<br>
        	5.Use window screens.<br>
        	6.Apply mosquito repellent with DEET (diethyltoluamide) to exposed skin.<br>
        	7.Drape mosquito netting over beds.<br>
        	8.Put screens on windows and doors.<br>
        	9.Treat clothing, mosquito nets, tents, sleeping bags and other fabrics with an insect repellent called permethrin.<br>
        	10.Wear long pants and long sleeves to cover your skin.<br>
        </p>
        <div>
            <a href="malaria precaution.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
        </div>
</div>
</body>
</html>