<html>
    <head>
        <title>Corona symptoms</title>
		<link rel="stylesheet" type="text/css" href="Loginpage.css">
    <link rel="icon" href="diseas.png" type="image/png">
    <script src="Js/jquery.js"></script>
    <script src="Dashboard.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

    </head>
    <body id="sty">
        
        <!--left-->
		<?php include('sidebar.php')?>
		

        <!--center-->
    <div id="diseas" style="width:100%;max-width:750px;">
        <div>
            <h1 align="center">Corona</h1>
        </div>
        <hr>
        <img src="corona symptoms.jpg"width="500" height="500">
        <div>
           <label> Most common symptoms:</label>
           <ol>
                <li>fever</li>
                <li>cough</li>
                <li>tiredness</li>
                
               <label> common symptoms:</label>
               <li> sore throat </li>
               <li> headache</li>
                <li>aches and pains</li>
                <li>diarrhoea</li>
                <li>a rash on skin, or discolouration of fingers or toes</li>
               <li>red or irritated eyes</li>
            </ol>
        </div>
		 <label>Save the file</label>
		<a href="corona_sympotms.pdf" download>
                <img src="download.jpg" width="50" height="30"  style="border:solid">
              </a>
    </div>
    </body>
</html>