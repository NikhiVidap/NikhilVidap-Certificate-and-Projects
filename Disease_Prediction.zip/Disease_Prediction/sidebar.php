<html>

<head>
    <title>Cancer Precautions</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
    <link rel="icon" href="diseas.png" type="image/png">
    <script src="Js/jquery.js"></script>
    <script src="Dashboard.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>

<body>
    <!--leftdiv-->
    <div class="firstdiv">

        <br>
        <label>Disease</label>
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp;<i class="fa-solid fa-bars fa-xl" onclick="buttonclick()"></i>
        &nbsp &nbsp &nbsp &nbsp;<a href="Disease prediction.php"><i class="fa-solid fa-house fa-2xl"
                style="color: #8fd6a4;"></i></a>
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp;<a href="Loginpage.php"><i class="fa-solid fa-power-off fa-xl"
                style="color: #e90707;"></i></a>


    </div>
    <div class="leftdiv" style="height:130%;">

        <!--corona-->
        <ul class="hov" onclick="coronaclick()">Corona <i class="fa-solid fa-angle-up" id="angelupcor"
                onclick="angelupcor()"></i>
            <i class="fa-solid fa-angle-down" id="angeldowncor" onclick="angeldowncor()"
                style="visibility: hidden;"></i>
            <a href="corona_sympotms.php" style="text-decoration: none;color:black">
                <li class="corona">symptoms</li>
            </a>
            <a href="corona_precaution.php" style="text-decoration: none;color:black">
                <li class="corona">Precaution</li>
            </a>
        </ul>



        <!--cancer-->
        <ul class="hov" onclick="cancerclick()">Cancer <i class="fa-solid fa-angle-up" id="angelupcan"
                onclick="angelupcan()"></i>
            <i class="fa-solid fa-angle-down" id="angeldowncan" onclick="angeldowncan()" style="visibility:hidden;"></i>
            <a href="cancer_sympotms.php" style="text-decoration: none;color:black">
                <li class="cancer">symptoms</li>
            </a>
            <a href="cancer precautions.php" style="text-decoration: none;color:black">
                <li class="cancer">Precaution</li>
            </a>
        </ul>


        <!--Sugar-->

        <ul class="hov" onclick="sugarclick()">Sugar <i class="fa-solid fa-angle-up" id="angelupsug"
                onclick="angelupsug()"></i>
            <i class="fa-solid fa-angle-down" id="angeldownsug" onclick="angeldownsug()" style="visibility:hidden;"></i>
            <a href="Sugar Symptoms.php" style="text-decoration: none;color:black">
                <li class="sugar">symptoms</li>
            </a>
            <a href="sugar precaution.php" style="text-decoration: none;color:black">
                <li class="sugar">Precaution</li>
            </a>
        </ul>


        <!--Chickenpox-->

        <ul class="hov" onclick="chickenclick()">Chickenpox <i class="fa-solid fa-angle-up" id="angelupchicken"
                onclick="angelupchicken()"></i>
            <i class="fa-solid fa-angle-down" id="angeldownchicken" onclick="angeldownchicken()"
                style="visibility:hidden;"></i>
            <a href="chicken pox symptoms.php" style="text-decoration: none;color:black">
                <li class="chicken">symptoms</li>
            </a>
            <a href="chicken-pox-precautions.php" style="text-decoration: none;color:black">
                <li class="chicken">Precaution</li>
            </a>
        </ul>


        <!--HIV-->

        <ul class="hov" onclick="hivclick()">HIV<i class="fa-solid fa-angle-up" id="angeluphiv"
                onclick="angeluphiv()"></i>
            <i class="fa-solid fa-angle-down" id="angeldownhiv" onclick="angeldownhiv()" style="visibility:hidden;"></i>
            <a href="hiv symptoms.php" style="text-decoration: none;color:black">
                <li class="hiv">symptoms</li>
            </a>
            <a href="hiv-precautions.php" style="text-decoration: none;color:black">
                <li class="hiv">Precaution</li>
            </a>
        </ul>


        <!--dengue-->
        <ul class="hov" onclick="dengueclick()">Dengue <i class="fa-solid fa-angle-up" id="angelupden"
                onclick="angelupden()"></i>
            <i class="fa-solid fa-angle-down" id="angeldownden" onclick="angeldownden()" style="visibility:hidden;"></i>
            <a href="Dengue Symptoms.php" style="text-decoration: none;color:black">
                <li class="dengue">symptoms</li>
            </a>
            <a href="dengue-precautions.php" style="text-decoration: none;color:black">
                <li class="dengue">Precaution</li>
            </a>
        </ul>


        <!--maleria-->
        <ul class="hov" onclick="maleriaclick()">Maleria <i class="fa-solid fa-angle-up" id="angelupmal"
                onclick="angelupmal()"></i>
            <i class="fa-solid fa-angle-down" id="angeldownmal" onclick="angeldownmal()" style="visibility:hidden;"></i>
            <a href="malaria-symptom.php" style="text-decoration: none;color:black">
                <li class="maleria">symptoms</li>
            </a>
            <a href="malaria precaution.php" style="text-decoration: none;color:black">
                <li class="maleria">Precaution</li>
            </a>
        </ul>


        <!--Thyroid-->

        <ul class="hov" onclick="thyroidclick()">Thyroid <i class="fa-solid fa-angle-up" id="angelupthy"
                onclick="angelupthy()"></i>
            <i class="fa-solid fa-angle-down" id="angeldownthy" onclick="angeldownthy()" style="visibility:hidden;"></i>
            <a href="thyroid-symptoms.php" style="text-decoration: none;color:black">
                <li class="thyroid">symptoms</li>
            </a>
            <a href="thyroid-precautions.php" style="text-decoration: none;color:black">
                <li class="thyroid">Precaution</li>
            </a>
        </ul>


        <!--Flu-->

        <ul class="hov" onclick="fluclick()">Flu <i class="fa-solid fa-angle-up" id="angelupflu"
                onclick="angelupflu()"></i>
            <i class="fa-solid fa-angle-down" id="angeldownflu" onclick="angeldownflu()" style="visibility:hidden;"></i>
            <a href="Flu Symptoms.php" style="text-decoration: none;color:black">
                <li class="flu">symptoms</li>
            </a>
            <a href="Flu Precautions.php" style="text-decoration: none;color:black">
                <li class="flu">Precaution</li>
            </a>
        </ul>


        <!--Typhoid-->

        <ul class="hov" onclick="typhoidclick()">Typhoid <i class="fa-solid fa-angle-up" id="angeluptyp"
                onclick="angeluptyp()"></i>
            <i class="fa-solid fa-angle-down" id="angeldowntyp" onclick="angeldowntyp()" style="visibility:hidden;"></i>
            <a href="Typhoid Symptoms.php" style="text-decoration: none;color:black">
                <li class="typhoid">symptoms</li>
            </a>
            <a href="Typhoid Precautions.php" style="text-decoration: none;color:black">
                <li class="typhoid">Precaution</li>
            </a>
        </ul>

    </div>

</body>

</html>