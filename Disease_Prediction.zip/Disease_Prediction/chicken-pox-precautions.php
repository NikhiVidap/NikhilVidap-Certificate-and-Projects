<html>
    <head>
		<title>Chickenpox precautions</title>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    </head>
    <Body>
        <!--left-->
    <?php include('sidebar.php')?>
       

        <!--center-->
    <div id="diseas" style="width:100%;max-width:750px;">
	    <div align="center">
	    <h3>Chickenpox precautions</h3>
	    </div>
	    <hr>
        <img src="chicken-pox-precautions.jpg" width="500" height="500">
        
            <label>The best way to prevent chickenpox is to get the chickenpox vaccine. Everyone—including children, adolescents, and adults—should get two doses of chickenpox vaccine if they have never had chickenpox or were never vaccinated. Chickenpox vaccine is very safe and effective at preventing the disease.

            </label>

            <label> is chickenpox spread?
            Children can get chickenpox at any age. After being exposed to chickenpox, your child may appear to be fine for one to three weeks before feeling sick. Children can spread the virus from one day before they show signs of illness to about five days after a skin rash appears.</label>

            <label> virus is spread by:</label>
            <ol>
                <li>Coming in contact with someone who has chickenpox.</li>
                <li>Breathing air from an infected person who sneezes or coughs.</li>
                <li>Coming in contact with fluids from an infected child's eyes, nose or mouth.</li>
            </ol>

    
        <div>
            <label>Save the file</label>
            <a href="Chickenpox precautions.pdf" download><img src="download.jpg" width="50" height="30"  style="border:solid" ></a>
        </div>
    </div>
    </Body>
</html>