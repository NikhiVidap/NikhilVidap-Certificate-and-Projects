<!DOCTYPE html>
<head>
    <title>Dengue Symptoms</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
<!--left-->

<?php include('sidebar.php')?>

    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Dengu Symptoms in children</h3>
    <hr>
    <br>
    <img src="dengue symptoms.jpg" width="500" height="500">
    <br>
    <br>
    <p>
        In comparison to adults, children often have less severe dengue symptoms. Here are a few possible signs of dengue in infants:<br>
        1.Longer than five days with a high temperature.<br>
        2.Decreased body temperature (less than 96.8 degrees F).<br>
        3.A skin rash.<br>
        4.Daily vomiting many times.<br>
        5.Nose and gum bleeding.<br>
        6.Feeling constantly drowsy.<br>
        7.Irritability.<br>
        8.Lots many tears.<br>
        </p>
        <p>
            Children and toddlers may also display the following signs:<br>
            1.Ocular discomfort or light sensitivity.<br>
            2.Headache.<br>
            3.Extreme fever.<br>
            4.Muscle ache.<br>
            5.Aching.<br> 
        </p>

        <p>
            Children with dengue may experience symptoms a few days after being bitten by an infected mosquito. In addition to the typical dengue signs, certain children may additionally go through the following: <br> 
        
            1.Body patches.<br>
            2.Nausea.<br>
            3.Reduced appetite.<br>
            4.Weakness.<br>
            5.Incapacity to engage in physical activity.<br>
        </p>
        <div>
            <label>Save the file</label>
            <a href="Dengue Symptoms in Children.pdf" download><img src="download.jpg" width="50" height="30" style="border: solid;"></a>
        </div>
        <br>
        <br>
        <h3 align="center">Dengu Symptoms in adult</h3>
        <hr><br>
        <img src="DengueSymptominadult.jpg" width="500" height="500">
        <br>
        <br>
        <p>
                Most people with dengue have mild or no symptoms and will get better in 1–2 weeks. Rarely, dengue can be severe and lead to death.  
            If symptoms occur, they usually begin 4–10 days after infection and last for 2–7 days. Symptoms may include:<br>
                1.high fever (40°C/104°F).<br>
                2.severe headache.<br>
                3.pain behind the eyes.<br>
                4.muscle and joint pains.<br>
                5.nausea.<br>
                6.vomiting.<br>
                7.swollen glands.<br>
                7.rash.<br>
        </p>
        <div>
            <label>Save the file</label>
            <a href="Dengue Symptoms in Adult.pdf" download><img src="download.jpg" width="50" height="30" style="border: solid;"></a>
        </div>
</div>
</body>
</html>