<!DOCTYPE html>
<head>
    <title>HIV Symptoms</title>
	<link rel="stylesheet" type="text/css" href="Loginpage.css">
	<link rel="icon" href="diseas.png" type="image/png">
	<script src="Js/jquery.js"></script>
	<script src="Dashboard.js" type="text/javascript"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
	<!--left-->

    <?php include('sidebar.php')?>
	
	
	<!--center-->
	<div id="diseas" style="width:100%;max-width:750px;">
			<h3 align="center">HIV Stages and Symptoms</h3>
			<hr>
			<img src="hiv-symptoms.jpg" width="500" height="500">
			<br>
			<br>
		<label> <b>Stage 1: Acute HIV Infection</b></label>
		<label>Within 2 to 4 weeks after infection with HIV, about two-thirds of people will have a flu-like illness. This is the body’s natural response to HIV infection.</label>
		<label>Flu-like symptoms can include:</label>
			<p>1.Fever<br>
			2.Chills<br>
			3.Rashes<br>
			4.Night sweats<br>
			5.Muscle aches<br>
			6.Sore throat<br>
			7.Fatigue<br>
			8.Swollen lymph nodes<br>
			9.Mouth ulcers<br></p>
		<label> symptoms can last anywhere from a few days to several weeks. But some people do not have any symptoms at all during this early stage of HIV.</label>

		<br><label> <b>Stage 2: Clinical Latency</b></label>
		<p>1.	In this stage, the virus still multiplies, but at very low levels. People in this stage may not feel sick or have any symptoms. This stage is also called chronic HIV infection.<br>
		2.	.Without HIV treatment, people can stay in this stage for 10 or 15 years, but some move through this stage faster.<br>
		3.	If you take HIV medicine exactly as prescribed and get and keep an undetectable viral load, you can live and long and healthy life and will not transmit HIV to your HIV-negative partners through sex.<br>
		But if your viral load is detectable, you can transmit HIV during this stage, even when you have no symptoms. It’s important to see your health care provider regularly to get your viral load checked.</p>
		<label><b>Stage 3: AIDS</b></label>
		<p>If you have HIV and you are not on HIV treatment, eventually the virus will weaken your body’s immune system and you will progress to AIDS (acquired immunodeficiency syndrome).
		This is the late stage of HIV infection.</p>
		<label>Symptoms of AIDS can include:</label>
		<p>
			1.Rapid weight loss.<br>
			2.Recurring fever or profuse night sweats.<br>
			3.Extreme and unexplained tiredness.<br>
			4.Prolonged swelling of the lymph glands in the armpits, groin, or neck.<br>
			5.Diarrhea that lasts for more than a week.<br>
			6.Sores of the mouth, anus, or genitals.<br>
			7.Pneumonia.<br>
			8.Red, brown, pink, or purplish blotches on or under the skin or inside the mouth, nose, or eyelids.<br>
			9.Memory loss, depression, and other neurologic disorders.</p>


			<div>
				<label>Save the file</label>
				<a href="HIV stages and symptoms.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
			</div>
	</div>

</body>
</html>