<html>
    <head>
        <title>Sugar Symptoms</title>
		<link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    </head>
    <body>
        <!--left-->
    <?php include('sidebar.php')?>
       
        <!--center-->
    <div id="diseas" style="width:100%;max-width:750px;">
        <h2 align="center">Sugar Symptoms</h2>
        <hr>
            <ol>
                <li>Urinate (pee) a lot, often at night</li>
                <li>Are very thirsty</li>
                <li>Lose weight without trying</li>
                <li>Are very hungry</li>
                <li>Have blurry vision</li>
                <li>Have numb or tingling hands or feet</li>
                <li>Feel very tired</li>
                <li>Have very dry skin</li>
                <li>Have sores that heal slowly</li>
                <li>Have more infections than usual</li>
            </ol>
       
            <h2 align="center">Symptoms of Type 1 Diabetes</h2>
        <hr>
        <img src="type1diabetes symptoms.jpg" width="500" height="500">
        <p>People who have type 1 diabetes may also have nausea, vomiting, or stomach pains. Type 1 diabetes symptoms can develop in just a few weeks or months and can be severe. Type 1 diabetes usually starts when you're a child, teen, or young adult but can happen at any age.</p>

        <h2 align="center">Symptoms of Type 2 Diabetes</h2>
        <hr>
        <img src="type 2 diabetes symptoms.jpg" width="500" height="500">
        <p>Type 2 diabetes symptoms often take several years to develop. Some people don't notice any symptoms at all. Type 2 diabetes usually starts when you're an adult, though more and more children and teens are developing it. Because symptoms are hard to spot, it's important to know the risk factors for type 2 diabetes. Make sure to visit your doctor if you have any of them.</p>
        <div>
            <label>Save the file</label>
            <a href="Sugar Symptoms.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
        </div>
    </div>
    </body>
</html>