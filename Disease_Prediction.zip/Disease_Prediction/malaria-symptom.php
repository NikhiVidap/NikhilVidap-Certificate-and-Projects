<!DOCTYPE html>
<head>
    <title>Malaria Symptoms</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
    <link rel="icon" href="diseas.png" type="image/png">
    <script src="Js/jquery.js"></script>
    <script src="Dashboard.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->
    <?php include('sidebar.php')?>
        <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Malaria Symptoms</h3>
    <hr>
    <br>
    <img src="malaria-symptom.jpg"width="500" height="500">
    <br>
    <br>
    <p>
            The most common early symptoms of malaria are fever, headache and chills.<br>
        Symptoms usually start within 10–15 days of getting bitten by an infected mosquito.<br>
        Symptoms may be mild for some people, especially for those who have had a malaria infection before. Because some malaria symptoms are not specific, getting tested early is important. <br>
        Some types of malaria can cause severe illness and death. Infants, children under 5 years, pregnant women, travellers and people with HIV or AIDS are at higher risk. Severe symptoms include:<br>
         	1.Fever.<br>
        	2.Chills.<br>
        	3.General feeling of discomfort.<br>
        	4.Headache.<br>
        	5.Nausea and vomiting.<br>
        	6.Diarrhea.<br>
        	7.Abdominal pain.<br>
        	8.Muscle or joint pain.<br>
        	9.Fatigue.<br>
        	10.Rapid breathing.<br>
        	11.Rapid heart rate.<br>
        	12.Cough.<br>
    </p>
    <div>
        <label>Save the file</label>
        <a href="malaria symptoms.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
    </div>
</div>
</body>
</html>