<html>
    <head>
		<title>Corona precautions</title>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
    <link rel="icon" href="diseas.png" type="image/png">
    <script src="Js/jquery.js"></script>
    <script src="Dashboard.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

    </head>
    <Body id="sty">
		<!--left-->
		<?php include('sidebar.php')?>
		   
	<!--center-->
	
	<div id="diseas" style="width:100%;max-width:750px;">
		<img src="corona precaution.jpg" width="500" height="500">
				<video controls width="370" height="440" style="border:solid">
					<source src="Corona precautions.mp4" type="video/mp4">
				</video>
				<br>
				<br>
				<label>Protect yourself and those around you:</label>
				
			<ol>
				<li>Get vaccinated as soon as it's your turn and follow local guidance on vaccination.</li>
				<li>Keep physical distance of at least 1 metre from others, even if they don't appear to be sick. Avoid crowds and close contact.</li>
				<li>Wear a properly fitted mask when physical distancing is not possible and in poorly ventilated settings.</li>
				<li>Clean your hands frequently with alcohol-based hand rub or soap and water.</li>
				<li>Cover your mouth and nose with a bent elbow or tissue when you cough or sneeze. Dispose of used tissues immediately and clean hands regularly. </li>
				<li>If you develop symptoms or test positive for COVID-19, self-isolate until you recover.</li>
		</ol>
		<label>To properly wear your mask:</label>
		<ol>
			<li>Make sure your mask covers your nose, mouth and chin.</li>
			<li>Clean your hands before you put your mask on, before and after you take it off, and after you touch it at any time.</li>
			<li>When you take off your mask, store it in a clean plastic bag, and every day either wash it if it’s a fabric mask or dispose of it in a trash bin if it’s a medical mask.</li>
			<li>Don't use masks with valves.</li>
		</ol>
		<labael>To make your environment as safe as possible:</labael>
		<ol>
			<li>Avoid the 3Cs: spaces that are closed, crowded or involve close contact.</li>
			<li>Meet people outside. Outdoor gatherings are safer than indoor ones, particularly if indoor spaces are small and without outdoor air coming in.</li>
			<li>If you can't avoid crowded or indoor settings, take these precautions:
			<ul><li>Open a window to increase the amount of natural ventilation when indoors.</li></ul>
		</ol>
		<label>To ensure good hygiene you should:</labael>
		<ol>
			<li>Regularly and thoroughly clean your hands with either an alcohol-based hand rub or soap and water. This eliminates germs that may be on your hands, including viruses.</li>
			<li>Cover your mouth and nose with your bent elbow or a tissue when you cough or sneeze. Dispose of the used tissue immediately into a closed bin and wash your hands.</li>
			<li>Clean and disinfect surfaces frequently, especially those which are regularly touched, such as door handles, faucets and phone screens.</li>
		</ol>

		<label>Save the file</label>
		<a href="Corona precautions.pdf" download><img src="download.jpg" width="50" height="30"  style="border:solid" ></a>
	</div>
    </Body>
</html>