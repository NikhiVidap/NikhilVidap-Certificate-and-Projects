<!DOCTYPE html>
<head>
    <title>Flu precautions</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->
    <?php include('sidebar.php')?>
    

    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Flu Precauions</h3>
    <hr>
    <br>
    <img src="flu precautions.jpg" width="500" height="500">
    <br>
    <br>
    <p>
            Flu precautions:<br>
        	1.Wash your hands often with soap and water. If you aren’t able to use soap and water, use an alcohol-based hand sanitizer.<br>
        	2.Cover your nose and mouth when you sneeze or cough. Cough or sneeze into your elbow or a tissue rather than your bare hand.<br>
        	3.Avoid being around other people when you or they are sick with the flu or other infectious diseases.<br>
        	4.Consider wearing a mask if you’re sick and can’t avoid being around others.<br>
        	5.Avoid touching your face, eyes, nose and mouth.<br>
        	6.Don’t share food or eating utensils (forks, spoons, cups) with others.<br>
    </p>
    <br>
    <div>
        <label>Save the file</label>
        <a href="Flu Precautions.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
    </div>
</div>
</body>
</html>