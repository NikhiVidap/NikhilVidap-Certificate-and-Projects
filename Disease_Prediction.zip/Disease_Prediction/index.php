

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <title>Registration Form</title>
		<link rel="icon" href="diseas.png" type="image/png">

    </head>
    <body id="bg">
        <br> <br><br>
        
        <form method="post" role="form" action="index.php" >
            <div>
                <h4 align="center" id="headers" >REGISTRATION FORM</h4>
            </div>
           
        <div class="bo" align="center" style="height:310px">
            
            <!-- <div align="center">
                <img src="diseas.png" width="100" height="50">
                <h3>Disease Prediction</h3>
            </div>
            -->
           
            <div>
                <label><br>First Name&nbsp   &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp;</label>
                <input type="text" name="name" required placeholder="Enter Name" class="nb">
            </div>
            <br>
            <div>
                <label>Last Name  &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp;</label>
                <input type="text" name="surname" required placeholder="Enter Surname" class="nb">
            </div>
            <br>
            <div>
                <label>Mobile Number  &nbsp &nbsp  &nbsp &nbsp;</label> 
                <input type="text" name="mobile" required placeholder="Enter Mobile Number" class="nb">
            </div>
            <br>
            <div>
                <lable>Address  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp;</lable>
                <input type="text" name="address" required placeholder="Enter Address" class="nb">
            </div>
            <br>
            <div>
                <label>Create Username &nbsp  &nbsp &nbsp;</label>
                <input type="text" name="username"required placeholder="Enter Username" class="nb"> 
            </div>
            <br>
            <div>
                <label>Create Password  &nbsp &nbsp &nbsp;</label>
                <input type="password" name="password" required placeholder="Enter Password " class="nb">
            </div>
            <br>
            <div >
    
            <input type="submit" name="register" class="butt" value="REGISTER"  style="cursor: pointer; font-family: arial;"> 
           
            </div>
            <br>
            <div style="font-family: arial;">
                <label>Already have an account?</label> 
                <a href="Loginpage.php" id="link">Login now</a>
            </div>
        </div>  
        </form>
        
    </body>
     
</html>





<?php
require_once('registration_connection.php');
if(isset($_POST['register']))
{
    
    $name=$_POST['name'];
    $surname=$_POST['surname'];
    $mobile=$_POST['mobile'];
    $address=$_POST['address'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $sql="INSERT INTO user_info(Name,Surname,Mobile,Address,Username,Password) VALUES(?,?,?,?,?,?)";
    $stmtinsert=$db->prepare($sql);
    $result=$stmtinsert->execute([$name,$surname,$mobile,$address,$username,$password]);
    
    if($result)
    {  
         echo"
         <script type='text/JavaScript'>
         alert('Successfully save data ');
         window.location= 'Loginpage.php';
         
         </script>";
            //echo"<br><br> <a href='Loginpage.html'>Goto login page</a>";
    

    }
    
    else
    {
        echo'
        <script type="text/JavaScript">
        alert("There were errors while saving the data")
        </script>
        ';
    }
    
   

    
    

}
/*if(isset($_POST['register']))
{
    echo"
    <script type='text/JavaScript'>
    alert('Successfully save data ')
    </script>";
   
   
}*/



?>









