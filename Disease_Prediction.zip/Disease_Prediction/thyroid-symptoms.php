<!DOCTYPE html>
<head>
    <title>Thyroid Symptoms</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
	<!--left-->
    <?php include('sidebar.php')?>
	
	<!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Thyroid Symptoms</h3>
    <hr>
    <br>
    <img src="thyroid-symptoms.jpg" width="500" height="500">
    <br>
    <br>
    <p>
            1.Changes in Heart Rate:<br>
        Thyroid hormones affect nearly every organ in the body and can influence how quickly the heart beats. People with hypothyroidism may notice their heart rate is slower than usual. Hyperthyroidism may cause the heart to speed up. It can also trigger increased blood pressure and the sensation of a pounding heart, or other types of heart palpitation.<br>

        	2.Anxiety.<br>
        	3.Difficulty concentrating.<br>
        	4.Fatigue.<br>
        	5.Frequent bowel movements.<br>
        	6.Hair loss.<br>
        	7.Hand tremor.<br>
        	8.Heat intolerance.<br>
        	9.Increased appetite.<br>
        	10Increased sweating.<br>
        	11.Irregular menstrual periods in women.<br>
        	12.Nail changes (thickness or flaking).<br>
        	13.Nervousness.<br>
        	14.Pounding or racing heart beat (palpitations).<br>
        	15.Restlessness.<br>
        	16.Sleep problems.<br>
        	17.Weight loss (or weight gain, in some cases).<br>
		</p>
		<div>
			<label>Save the file</label>
			<a href="Thyroid Symptoms.pdf" download><img src="download.jpg" widht="50" height="30" style="border:solid"></a>
		</div>
</div>
</body>
</html>