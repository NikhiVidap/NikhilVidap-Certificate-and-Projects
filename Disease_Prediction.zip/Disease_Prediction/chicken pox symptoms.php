<!DOCTYPE html>
<head>
    <title>Chickenpox</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
    <link rel="icon" href="diseas.png" type="image/png">
    <script src="Js/jquery.js"></script>
    <script src="Dashboard.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->

    <?php include('sidebar.php')?>
    
    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h2 align="center">Chickenpox Symptoms</h2>
    <hr>
    <img src="chickenpox symptoms.jpg" width="300" height="300">
    <br>
    <br>
    <label> The itchy blister rash caused by chickenpox infection appears 10 to 21 days after exposure to the virus and usually lasts about five to 10 days. Other signs and symptoms, which may appear one to two days before the rash, include:</label>
    <ol>
       <li>Fever</li>
       <li>Loss of appetite</li>
       <li>Headache</li>
       <li>Tiredness and a general feeling of being unwell (malaise)</li>
    </ol>
        <label>Once the chickenpox rash appears, it goes through three phases:</label>
    <ol>
        <li>Raised pink or red bumps (papules), which break out over several days</li>
        <li>Small fluid-filled blisters (vesicles), which form in about one day and then break and leak</li>
        <li>Crusts and scabs, which cover the broken blisters and take several more days to heal</li>
    </ol>
    
    <div>
        <label>Save the file</label>
        <a href="chicken pox symptoms.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
    </div>
</div>
</body>
</html>