<!Doctype html>
<head>
    <title>Typhoid Symptoms</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->
    <?php include('sidebar.php')?>
    
    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 >Typhoid Symptoms</h3>
    <hr>
    <br>
    <img src="Typhoid Symptoms.jpg" width="500" height="500">
    <br>
    <br>
    <div>
    <p>
        Symptoms typically begin 1-3 weeks after exposure to the bacteria.<br>
        The two main symptoms of typhoid are fever and rash. Typhoid fever is particularly high, gradually increasing over several days up to 104ºF.<br>
        The rash, which does not affect every person, consists of rose-colored spots, particularly on the neck and abdomen.<br>
        	1.Headache.<br>
        	2.Chills.<br>
        	3.Loss of appetite.<br>
        	4.Stomach (abdominal) pain.<br>
        	5."Rose spots" rash, or faint pink spots, usually on your chest or stomach.<br>
        	6.Cough.<br>
        	7.Muscle aches.<br>
        	8.Nausea, vomiting.<br>
        	9.Diarrhea or constipation.<br>
        </p>
    
        <div>
            <label>Save the file</label>
            <a href="Typhoid Symptoms.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
        </div>

        <h3>Stages of Typhoid</h3>
        <hr>
        <br>
        <p>
            What are the stages of typhoid fever?<br>
            You can develop symptoms of typhoid fever gradually in four stages. Early treatment with antibiotics can keep you from progressing to later stages.<br><br>
            <b>Stage 1.</b> You can start getting typhoid symptoms anywhere from five to 14 days after coming in contact with Typhoid The first symptom is a fever that gets higher over a few days-called "stepwise" since it goes up in steps. The bacteria is moving into your blood in this stage.<br><br>
            <b>Stage 2.</b> Around the second week of fever, the bacteria is multiplying in your Peyer's patches (part of your immune system that identifies harmful invaders). You'll start experiencing abdominal pain and other stomach symptoms, like diarrhea or constipation. You might get "rose spots" small pink dots on your skin that look like a rash.<br><br>
            <b>Stage 3.</b> If not treated with antibiotics, the bacteria can cause severe damage, usually around the third week after your symptoms start. Some people get serious complications, like internal bleeding and encephalitis (inflammation in your brain).<br><br>
            <b>Stage 4.</b> Stage four is when most people begin to recover. Your high fever begins to come down Typhoid can live in your gallbladder without causing symptoms, which means you may still be contagious even after you feel better.
            </p>
        <div>
            <label>Save the file</label>
            <a href="Stages of Typhoid.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
        </div>
</div>
</body>
</html>