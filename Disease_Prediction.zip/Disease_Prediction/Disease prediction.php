<html>
<head>
    <title>Disease prediction</title>
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
    <link rel="icon" href="diseas.png" type="image/png">
    <script src="Js/jquery.js"></script>
    <script src="Dashboard.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />



</head>
<body id="sty">
    <div>
        <h1 style="margin-left: 30%;">Disease Prediction <i class="fa-solid fa-heart-pulse fa-beat fa-xl" style="color: #d40c0c;"></i>
        
        </h1> 
    
    </div>
    <hr>
    <hr>

        <form>
            

            <!-- <div class="firstdiv">
			
                <br>
                <label>Disease</label>
                &nbsp  &nbsp  &nbsp  &nbsp &nbsp  &nbsp;<i class="fa-solid fa-bars fa-xl" onclick="buttonclick()"></i>
                &nbsp  &nbsp  &nbsp  &nbsp &nbsp  &nbsp;<a href="Loginpage.php"><i class="fa-solid fa-power-off fa-xl" style="color: #e90707;"></i></a>
    
                
            </div> -->
    <?php include('sidebar.php')?>
               
        
       
        

        </form>
   
           
    
    
</body>
</html>