<!DOCTYPE html>
<html>
    <head>
        <title>Disease Prediction login</title>
        <link rel="stylesheet" type="text/css" href="Loginpage.css">
		<link rel="icon" href="diseas.png" type="image/png">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
        
    </head>
    <body id="bgr">
        <br><br> <br><br><br><br>

        <form   method="post" role="form" action="Loginpage.php" align="center"> 
        <label style="color:white; font-size:60px;font-family:Arial">Disease Prediction</label>
        <br>
        <img src="diseas.png" width="60" height="40">
        <div id="background"  style="width:100%;max-width:750px;"> 
        
               
            <br> <br><br>  
                 
             <div class="col-md-12 text-center">
                <label style="color: white; font-family:Arial ;">LOGIN</label>
            </div>
            <br>
            <div align="center" id="colors">
            <i class="fa-solid fa-user"></i>
                <input type="text" style="border: none;" name="username" placeholder="Enter UserName"id="bord" required>
            </div>
            <br>
            <div align="center" id="colors">
                 <i class="fa-solid fa-key"></i>
                 <input type="password" style="border: none;" class="ver" name='Passwords' placeholder="Enter Password" required >
            </div>
        
            <br>
            <div align="center">
               <label></label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp;
             <input type="submit" name="submit" value="Login" class="but">
             <br>
             <br>
             <a href="forgot_password.php" style="color: white;font-family:Arial; text-decoration: none;">Forgot Password?</a>
            

            </div>
            <div>
                
            </div>
        
        </div>

        </form>
    </body>
    </html>
        

    
<?php 
require'registration_connection.php';

if(isset($_POST['Passwords']))
{
 
   $username=$_POST['username'];
   $Passwords=$_POST['Passwords'];
   
   $query="SELECT * FROM `user_info` WHERE Username=Username AND Password=Password";
   $data=mysqli_query($connect,$query);
   

   $datas=array();
   if(mysqli_num_rows($data)>0)
   {
      while($ans=mysqli_fetch_assoc($data))
      {
         
          $datas[]=$ans;
         
      }
   }

   
   
   foreach($datas as $sol)
   {  
      
      if($Passwords==$sol['Password'] && $username==$sol['Username'])
         {  
            $value=boolval(1);
               
         }
      else         
         {
         
            $value=boolval(0);
            
         }

      
      
   }
   
   if($value==boolval(1))
   {
      echo"
   
      <script>
      alert('Succcessfully Login');
      window.location= 'Disease prediction.php';
      
      </script>
      ";
      
   }
   elseif($values==boolval(0))
   {
      echo"
      <script>
      
      alert('Wrong username and password');
      </script>
      ";

   }
}






 
?>



























