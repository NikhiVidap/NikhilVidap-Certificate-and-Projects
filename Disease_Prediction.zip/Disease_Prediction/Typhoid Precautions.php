<!DOCTYPE html>
<head>
    <title>Typhoid Precautions</title> 
    <link rel="stylesheet" type="text/css" href="Loginpage.css">
        <link rel="icon" href="diseas.png" type="image/png">
        <script src="Js/jquery.js"></script>
        <script src="Dashboard.js" type="text/javascript"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!--left-->
    <?php include('sidebar.php')?>
    
    <!--center-->
<div id="diseas" style="width:100%;max-width:750px;">
    <h3 align="center">Typhoid Precautions</h3>
    <hr>
    <br>
    <img src="Typhoid precautions.jpg" width="500" height="500">
    <br>
    <br>
    <p>
        Safe food practices for preventing typhoid fever
        Vaccines are the best way to protect yourself from typhoid. But you should also take steps to avoid eating or drinking things that could be contaminated with S.Typhi or other bacteria. This is true both at home and when you’re traveling.<br> 
        Safe food handling practices include:<br>
        	1.Don’t make food for others if you’re sick.<br>
        	2.Wash your hands with soap and water before and after preparing food or eating and after going to the bathroom.<br>
        	3.Wash surfaces and utensils used for food prep and eating before and after use.<br>
        	4.If you’re unsure whether the food you’re eating is safe, eat mostly well-cooked or packaged food.<br>
        	5.Don’t drink untreated water or eat food prepared with untreated water. If you’re unsure, it’s safest to use bottled water to drink and cook with.<br>
        </p>
        <br>
        <div>
            <label>Save the file</label>
            <a href="Typhoid Precautions.pdf" download><img src="download.jpg" width="50" height="30" style="border:solid"></a>
        </div>
</div>
</body>
</html>