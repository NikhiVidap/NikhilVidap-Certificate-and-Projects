package com.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.web.entity.Books;
import com.web.service.BookServiceImp;

@Controller
public class BooksController {
	
	@Autowired
	private BookServiceImp service;

	@RequestMapping("/")
	public String homePage()
	{
		return "home";
	}
	
	@RequestMapping("/addbook")
	public String adduserform()
	{
		return "addbook";
	}
	@RequestMapping("/save")
	
	public String saveUserDetails(Books book,ModelMap model)
	{
		service.saveBook(book);
		return "success";
	}
	@RequestMapping("/viewBook")
	public String getAllBook(ModelMap model)
	{
		model.put("Books", service.getAllBooks());
		return "viewBook";
	}
	
	@RequestMapping("/delete/{book_id}")
	public String delete(@PathVariable int book_id)
	{
		service.deleteBook(book_id);
		return "redirect:/viewBook";
	}
	
	@RequestMapping("/edit/{book_id}")
	public String editForm(@PathVariable int book_id,ModelMap model)
	{
		model.put("command", service.getBook(book_id));
		return "editBook";
	}
	
	@RequestMapping ("/editbook")
	public String editAndSaveUserDetails(Books book,ModelMap model) {
		service.editBook(book);
		return "redirect:/viewBook";
	}

}
