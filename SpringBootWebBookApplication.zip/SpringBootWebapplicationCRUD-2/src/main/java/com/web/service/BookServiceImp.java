package com.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.entity.Books;

import com.web.repo.BooksRepo;

@Service
public class BookServiceImp implements BookService {
	@Autowired
	private BooksRepo repo;
	@Override
	public Books saveBook(Books book) {
		// TODO Auto-generated method stub
		
		return repo.save(book);
	}

	@Override
	public Books editBook(Books book) {
		// TODO Auto-generated method stub
		return  repo.save(book);
	}

	@Override
	public void deleteBook(int book_id) {
		// TODO Auto-generated method stub
		repo.deleteById(book_id);

	}

	@Override
	public Books getBook(int book_id) {
		// TODO Auto-generated method stub
		Books getOne=repo.findById(book_id).get();
		return getOne;
	}

	@Override
	public List<Books> getAllBooks() {
		// TODO Auto-generated method stub
		List<Books> getAll=(List<Books>)repo.findAll();
		return getAll;
	}

}
