package com.web.service;

import java.util.List;

import com.web.entity.Books;

public interface BookService {

	public Books saveBook(Books book);
	public Books editBook(Books book);
	public void deleteBook(int id);
	public Books getBook(int id);
	public List<Books> getAllBooks();
}
