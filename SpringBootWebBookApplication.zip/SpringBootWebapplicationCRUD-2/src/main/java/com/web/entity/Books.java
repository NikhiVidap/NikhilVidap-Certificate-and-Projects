package com.web.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Books {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int book_id;
	private String bname;
	private String bnumber;
	private String bprice;
	private String aname;
	private String pname;
	private int pyear;
	private String bedition;
	public Books() {
		super();
	}
	public Books(int book_id, String bname, String bnumber, String bprice, String aname, String pname, int pyear,
			String bedition) {
		super();
		this.book_id = book_id;
		this.bname = bname;
		this.bnumber = bnumber;
		this.bprice = bprice;
		this.aname = aname;
		this.pname = pname;
		this.pyear = pyear;
		this.bedition = bedition;
	}
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBnumber() {
		return bnumber;
	}
	public void setBnumber(String bnumber) {
		this.bnumber = bnumber;
	}
	public String getBprice() {
		return bprice;
	}
	public void setBprice(String bprice) {
		this.bprice = bprice;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPyear() {
		return pyear;
	}
	public void setPyear(int pyear) {
		this.pyear = pyear;
	}
	public String getBedition() {
		return bedition;
	}
	public void setBedition(String bedition) {
		this.bedition = bedition;
	}
	@Override
	public String toString() {
		return "Books [book_id=" + book_id + ", bname=" + bname + ", bnumber=" + bnumber + ", bprice=" + bprice
				+ ", aname=" + aname + ", pname=" + pname + ", pyear=" + pyear + ", bedition=" + bedition + "]";
	}
	
	
}
