package com.web.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.web.entity.Books;

@Repository
public interface BooksRepo extends  CrudRepository<Books,Integer>  {

}
